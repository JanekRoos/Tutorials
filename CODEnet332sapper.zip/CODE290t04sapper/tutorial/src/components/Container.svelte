<style>
  /* Style container to be a max width of 50rem */
</style>

<div>
  <!-- Define a slot to include children -->
</div>
