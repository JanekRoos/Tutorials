// Start up Sapper and mount it into the host element
