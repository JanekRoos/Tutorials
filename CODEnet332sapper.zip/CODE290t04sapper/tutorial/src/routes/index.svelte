<script context="module">
  // Fetch blog posts and pre-load their contents
</script>

<script>
  // Import used components

  // Export custom attributes for component
</script>

<style>
  /* Style a grid to display blog posts */
  ul {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(15rem, 1fr));
    grid-gap: 2rem;
    list-style: none;
    padding: 0;
  }
</style>

<!-- Update the title for the main blog page -->

<!-- Loop over posts and create a summary for each -->
