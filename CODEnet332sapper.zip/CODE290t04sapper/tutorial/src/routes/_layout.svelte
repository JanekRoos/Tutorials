<script>
  // Import components to build layout
</script>

<!-- Create layout -->
<main>
  <!-- Add slot for page content -->
  <slot />
</main>
