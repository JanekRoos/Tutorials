// Import markdown posts

// Only supply data needed for the index view

// Send data on request
export function get(req, res) {}
