<style>
  /* Style container to be a max width of 50rem */
  div {
    margin: 0 auto;
    padding: 0 1rem;
    max-width: 50rem;
  }
</style>

<!-- Define a slot to include children -->
<div>
  <slot />
</div>
