<script>
  // Import components to build layout
  import Header from "../components/Header.svelte";
</script>

<!-- Create layout -->
<main>
  <Header />
  <!-- Add slot for page content -->
  <slot />
</main>
