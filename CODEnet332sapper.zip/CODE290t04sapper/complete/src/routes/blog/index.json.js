// Import markdown posts
import posts from "./_posts.js";

// Only supply data needed for the index view
const contents = JSON.stringify(
  posts.map(post => ({
    author: post.author,
    image: post.image,
    title: post.title,
    slug: post.slug
  }))
);

// Send data on request
export function get(req, res) {
  res.writeHead(200, {
    "Content-Type": "application/json"
  });

  res.end(contents);
}
