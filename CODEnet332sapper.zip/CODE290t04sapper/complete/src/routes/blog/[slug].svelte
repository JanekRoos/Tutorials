<script context="module">
  // Load the requested post data
  export async function preload({ params }) {
    const res = await this.fetch(`blog/${params.slug}.json`);
    const data = await res.json();

    if (res.status === 200) {
      return { post: data };
    } else {
      this.error(res.status, data.message);
    }
  }
</script>

<script>
  // Import container component
  import Container from "../../components/Container.svelte";

  // Export post attribute
  export let post;
</script>

<style>
  h1 {
    margin: 0;
    margin-bottom: 0.25rem;
  }

  .byline {
    color: #888;
  }

  .post-image {
    background: #eee;
    display: block;
    width: 100%;
  }

  .title {
    margin: 2rem 0;
  }
</style>

<!-- Style each post -->

<!-- Set the page's <title> element to the post's title -->
<svelte:head>
  <title>{post.title} | Sapper Blog</title>
</svelte:head>

<!-- Display the post content -->
<article>
  <Container>
    <div class="title">
      <h1>{post.title}</h1>
      <div class="byline">by {post.author.name}</div>
    </div>
    <img class="post-image" src={post.image} alt="" />
    {@html post.html}
  </Container>
</article>
